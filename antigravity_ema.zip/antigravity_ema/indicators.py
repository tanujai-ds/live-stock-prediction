"""
Anti-Gravity EMA Trading System
Indicators Module — EMA 7 / 14 / 21 + Volume analysis
"""
import pandas as pd
import numpy as np
from config import config


def calc_ema(series: pd.Series, period: int) -> pd.Series:
    """Exponential Moving Average using pandas ewm (span = period)."""
    return series.ewm(span=period, adjust=False).mean()


def add_emas(df: pd.DataFrame) -> pd.DataFrame:
    """Add EMA7, EMA14, EMA21 columns to a candle DataFrame."""
    df = df.copy()
    df["ema7"]  = calc_ema(df["close"], config.EMA_SHORT)
    df["ema14"] = calc_ema(df["close"], config.EMA_MID)
    df["ema21"] = calc_ema(df["close"], config.EMA_LONG)
    return df


def add_volume_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add volume analysis columns:
        vol_avg      — rolling average volume (20 periods)
        vol_ratio    — current volume / avg volume
        vol_above    — True when volume > multiplier × avg
    """
    df = df.copy()
    df["vol_avg"]   = df["volume"].rolling(config.VOLUME_AVG_PERIOD).mean()
    df["vol_ratio"] = df["volume"] / df["vol_avg"]
    df["vol_above"] = df["vol_ratio"] >= config.VOLUME_MULTIPLIER
    return df


def trend_strength(df: pd.DataFrame) -> pd.Series:
    """
    TrendStrength = (EMA7 - EMA21) / Price
    Positive → bullish, Negative → bearish
    """
    return (df["ema7"] - df["ema21"]) / df["close"]


def add_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Convenience: add EMAs, volume metrics and trend strength in one call."""
    df = add_emas(df)
    df = add_volume_metrics(df)
    df["trend_strength"] = trend_strength(df)
    return df
