"""
Anti-Gravity EMA Trading System
Signal Engine — BUY / SELL / HOLD generation
"""
import pandas as pd
import numpy as np
from typing import Literal
from config import config

Signal = Literal["BUY", "SELL", "HOLD"]


def _bullish_crossover(df: pd.DataFrame, i: int) -> bool:
    """EMA7 crosses above EMA14 between bar i-1 and bar i."""
    if i < 1:
        return False
    prev = df.iloc[i - 1]
    curr = df.iloc[i]
    return (prev["ema7"] <= prev["ema14"]) and (curr["ema7"] > curr["ema14"])


def _bearish_crossover(df: pd.DataFrame, i: int) -> bool:
    """EMA7 crosses below EMA14 between bar i-1 and bar i."""
    if i < 1:
        return False
    prev = df.iloc[i - 1]
    curr = df.iloc[i]
    return (prev["ema7"] >= prev["ema14"]) and (curr["ema7"] < curr["ema14"])


def classify_signal(row: pd.Series, prev_row: pd.Series) -> Signal:
    """
    BUY  — EMA7 > EMA14 > EMA21  AND  volume above avg  AND  bullish crossover
    SELL — EMA7 < EMA14 < EMA21  AND  volume weakening   AND  bearish crossover
    HOLD — everything else
    """
    bullish_alignment = (
        row["ema7"] > row["ema14"] > row["ema21"]
    )
    bearish_alignment = (
        row["ema7"] < row["ema14"] < row["ema21"]
    )
    bull_cross = (prev_row["ema7"] <= prev_row["ema14"]) and (row["ema7"] > row["ema14"])
    bear_cross = (prev_row["ema7"] >= prev_row["ema14"]) and (row["ema7"] < row["ema14"])

    volume_strong = row.get("vol_above", False)
    # Volume weakening = vol_ratio < 1 or falling
    volume_weak = row.get("vol_ratio", 1.0) < 1.0

    if bullish_alignment and bull_cross and volume_strong:
        return "BUY"
    if bearish_alignment and bear_cross and volume_weak:
        return "SELL"
    return "HOLD"


def generate_signals(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply signal logic to every row.
    Adds columns: signal, buy_signal, sell_signal
    """
    df = df.copy()
    signals = ["HOLD"] * len(df)

    for i in range(1, len(df)):
        row      = df.iloc[i]
        prev_row = df.iloc[i - 1]
        signals[i] = classify_signal(row, prev_row)

    df["signal"]     = signals
    df["buy_signal"]  = df["signal"] == "BUY"
    df["sell_signal"] = df["signal"] == "SELL"
    return df


def latest_signal(df: pd.DataFrame) -> dict:
    """Return a dict with the latest bar's signal info."""
    row = df.iloc[-1]
    return {
        "signal":         row.get("signal", "HOLD"),
        "price":          float(row["close"]),
        "ema7":           float(row["ema7"]),
        "ema14":          float(row["ema14"]),
        "ema21":          float(row["ema21"]),
        "trend_strength": float(row.get("trend_strength", 0)),
        "vol_ratio":      float(row.get("vol_ratio", 1)),
        "timestamp":      row["timestamp"],
    }
