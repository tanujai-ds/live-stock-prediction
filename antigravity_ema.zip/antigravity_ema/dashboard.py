"""
Anti-Gravity EMA Trading System
Main Streamlit Dashboard
Run with: streamlit run dashboard.py
"""
import time
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
from datetime import datetime

from config import config
from data_fetcher import fetch_ohlcv, get_available_symbols
from indicators import add_all_indicators
from signal_engine import generate_signals, latest_signal
from trend_analyzer import analyze_trend, get_trend_label
from paper_trading import PaperTrader
from backtesting import run_backtest
from alerts import alert_signal
from database import load_signals, load_trades, save_signal, save_candles

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Anti-Gravity EMA System",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .metric-card {
        background: #1e1e2e;
        border-radius: 10px;
        padding: 14px 18px;
        text-align: center;
        border: 1px solid #3a3a5c;
    }
    .signal-buy  { color: #00c853; font-size: 2rem; font-weight: 700; }
    .signal-sell { color: #d50000; font-size: 2rem; font-weight: 700; }
    .signal-hold { color: #ffd740; font-size: 2rem; font-weight: 700; }
    .stMetric > div { color: #e0e0e0; }
</style>
""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
if "paper_trader" not in st.session_state:
    st.session_state.paper_trader = PaperTrader(config.INITIAL_BALANCE)
if "prev_trend" not in st.session_state:
    st.session_state.prev_trend = None
if "last_signal" not in st.session_state:
    st.session_state.last_signal = "HOLD"

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.image("https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg", width=40)
    st.title("🚀 Anti-Gravity EMA")
    st.caption("Free Live Trading Dashboard")
    st.divider()

    symbol    = st.selectbox("Symbol",    ["BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "XRP/USDT"], index=0)
    timeframe = st.selectbox("Timeframe", config.TIMEFRAMES, index=2)
    limit     = st.slider("Candles", 50, 500, config.CANDLE_LIMIT, step=50)
    refresh   = st.slider("Auto-refresh (s)", 10, 120, config.REFRESH_INTERVAL, step=5)

    st.divider()
    st.subheader("⚙️ EMA Settings")
    ema_s = st.number_input("EMA Short", 3, 20,  config.EMA_SHORT)
    ema_m = st.number_input("EMA Mid",   5, 50,  config.EMA_MID)
    ema_l = st.number_input("EMA Long", 10, 100, config.EMA_LONG)

    st.divider()
    st.subheader("🛡️ Risk Settings")
    sl_pct  = st.slider("Stop Loss %",    0.5, 10.0, config.STOP_LOSS_PCT * 100,   0.5) / 100
    tp_pct  = st.slider("Take Profit %",  0.5, 20.0, config.TAKE_PROFIT_PCT * 100, 0.5) / 100
    pos_pct = st.slider("Position Size %",1.0, 50.0, config.POSITION_SIZE_PCT * 100,1.0) / 100

    st.divider()
    enable_tg = st.toggle("Telegram Alerts", value=False)
    config.ENABLE_TELEGRAM = enable_tg
    if enable_tg:
        config.TELEGRAM_TOKEN   = st.text_input("Bot Token", type="password")
        config.TELEGRAM_CHAT_ID = st.text_input("Chat ID")

    st.divider()
    if st.button("🔄 Reset Paper Trader"):
        st.session_state.paper_trader = PaperTrader(config.INITIAL_BALANCE)
        st.success("Paper trader reset!")


# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_live, tab_backtest, tab_paper, tab_logs = st.tabs([
    "📊 Live Dashboard", "🔬 Backtest", "💼 Paper Trading", "📋 Logs & DB"
])

# ═══════════════════════════════════════════════════════════════════════════════
# TAB 1 — LIVE DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════
with tab_live:
    st.header(f"🚀 Anti-Gravity EMA — {symbol} [{timeframe}]")
    placeholder = st.empty()

    def render_live():
        with placeholder.container():
            # ── Fetch & process data ──────────────────────────────────────
            try:
                with st.spinner("Fetching live data…"):
                    config.EMA_SHORT = ema_s
                    config.EMA_MID   = ema_m
                    config.EMA_LONG  = ema_l

                    df = fetch_ohlcv(symbol, timeframe, limit)
                    df = add_all_indicators(df)
                    df = generate_signals(df)
                    save_candles(df, symbol, timeframe)
            except Exception as e:
                st.error(f"⚠️ Data fetch error: {e}")
                return

            sig_info   = latest_signal(df)
            trend_info = analyze_trend(df)
            signal     = sig_info["signal"]
            trader     = st.session_state.paper_trader

            # ── Save signal to DB ─────────────────────────────────────────
            if signal != "HOLD":
                save_signal({
                    "symbol":         symbol,
                    "timeframe":      timeframe,
                    "timestamp":      int(df.iloc[-1]["timestamp"].timestamp()),
                    "signal":         signal,
                    "price":          sig_info["price"],
                    "ema7":           sig_info["ema7"],
                    "ema14":          sig_info["ema14"],
                    "ema21":          sig_info["ema21"],
                    "trend_strength": sig_info["trend_strength"],
                    "volume_ratio":   sig_info["vol_ratio"],
                    "ai_confidence":  None,
                })
                if signal != st.session_state.last_signal:
                    alert_signal(signal, symbol, sig_info["price"],
                                 sig_info["trend_strength"], timeframe)
                    st.session_state.last_signal = signal

            # ── Paper trade execution ─────────────────────────────────────
            event = trader.on_signal(signal, sig_info["price"], symbol)

            # ── Trend reversal alert ──────────────────────────────────────
            curr_trend = trend_info["trend_label"]
            if st.session_state.prev_trend and st.session_state.prev_trend != curr_trend:
                from alerts import alert_reversal
                alert_reversal(symbol, st.session_state.prev_trend, curr_trend, sig_info["price"])
            st.session_state.prev_trend = curr_trend

            # ── Top KPI row ───────────────────────────────────────────────
            k1, k2, k3, k4, k5 = st.columns(5)
            k1.metric("💰 Price",     f"${sig_info['price']:,.2f}")
            k2.metric("📈 EMA 7",     f"${sig_info['ema7']:,.2f}")
            k3.metric("📊 EMA 14",    f"${sig_info['ema14']:,.2f}")
            k4.metric("📉 EMA 21",    f"${sig_info['ema21']:,.2f}")
            k5.metric("⚡ Vol Ratio", f"{sig_info['vol_ratio']:.2f}x")

            st.divider()

            # ── Signal + Trend + Strength row ────────────────────────────
            c1, c2, c3, c4 = st.columns(4)

            sig_class = f"signal-{signal.lower()}"
            c1.markdown(f"""
                <div class='metric-card'>
                    <div style='color:#aaa;font-size:13px'>SIGNAL</div>
                    <div class='{sig_class}'>{signal}</div>
                </div>
            """, unsafe_allow_html=True)

            c2.markdown(f"""
                <div class='metric-card'>
                    <div style='color:#aaa;font-size:13px'>TREND</div>
                    <div style='color:{trend_info["trend_color"]};font-size:1.4rem;font-weight:700'>
                        {trend_info["trend_label"]}
                    </div>
                </div>
            """, unsafe_allow_html=True)

            ts_val  = sig_info["trend_strength"] * 100
            ts_color = "#00c853" if ts_val > 0 else "#d50000"
            c3.markdown(f"""
                <div class='metric-card'>
                    <div style='color:#aaa;font-size:13px'>TREND STRENGTH</div>
                    <div style='color:{ts_color};font-size:1.4rem;font-weight:700'>
                        {ts_val:+.3f}%
                    </div>
                </div>
            """, unsafe_allow_html=True)

            port = trader.portfolio()
            pnl_color = "#00c853" if port["total_pnl"] >= 0 else "#d50000"
            c4.markdown(f"""
                <div class='metric-card'>
                    <div style='color:#aaa;font-size:13px'>PAPER P&L</div>
                    <div style='color:{pnl_color};font-size:1.4rem;font-weight:700'>
                        ${port["total_pnl"]:+.2f}
                    </div>
                </div>
            """, unsafe_allow_html=True)

            st.divider()

            # ── Candlestick chart ─────────────────────────────────────────
            bg_color = "rgba(0,200,83,0.04)" if signal == "BUY" else \
                       "rgba(213,0,0,0.04)"  if signal == "SELL" else \
                       "rgba(255,215,64,0.02)"

            fig = make_subplots(
                rows=2, cols=1,
                shared_xaxes=True,
                row_heights=[0.75, 0.25],
                vertical_spacing=0.03,
            )

            # Candlesticks
            fig.add_trace(go.Candlestick(
                x=df["timestamp"],
                open=df["open"], high=df["high"],
                low=df["low"],  close=df["close"],
                name="OHLCV",
                increasing_line_color="#00c853",
                decreasing_line_color="#d50000",
            ), row=1, col=1)

            # EMA lines
            fig.add_trace(go.Scatter(x=df["timestamp"], y=df["ema7"],
                line=dict(color="#FFD740", width=1.5), name=f"EMA{ema_s}"), row=1, col=1)
            fig.add_trace(go.Scatter(x=df["timestamp"], y=df["ema14"],
                line=dict(color="#40C4FF", width=1.5), name=f"EMA{ema_m}"), row=1, col=1)
            fig.add_trace(go.Scatter(x=df["timestamp"], y=df["ema21"],
                line=dict(color="#FF6D00", width=1.5), name=f"EMA{ema_l}"), row=1, col=1)

            # BUY arrows
            buy_df = df[df["buy_signal"]]
            if not buy_df.empty:
                fig.add_trace(go.Scatter(
                    x=buy_df["timestamp"],
                    y=buy_df["low"] * 0.999,
                    mode="markers+text",
                    marker=dict(symbol="triangle-up", color="#00c853", size=14),
                    text=["BUY"] * len(buy_df),
                    textposition="bottom center",
                    textfont=dict(color="#00c853", size=10),
                    name="BUY",
                ), row=1, col=1)

            # SELL arrows
            sell_df = df[df["sell_signal"]]
            if not sell_df.empty:
                fig.add_trace(go.Scatter(
                    x=sell_df["timestamp"],
                    y=sell_df["high"] * 1.001,
                    mode="markers+text",
                    marker=dict(symbol="triangle-down", color="#d50000", size=14),
                    text=["SELL"] * len(sell_df),
                    textposition="top center",
                    textfont=dict(color="#d50000", size=10),
                    name="SELL",
                ), row=1, col=1)

            # Volume bars
            vol_colors = ["#00c853" if c >= o else "#d50000"
                          for c, o in zip(df["close"], df["open"])]
            fig.add_trace(go.Bar(
                x=df["timestamp"], y=df["volume"],
                marker_color=vol_colors, name="Volume",
                opacity=0.7,
            ), row=2, col=1)

            # Volume avg line
            if "vol_avg" in df.columns:
                fig.add_trace(go.Scatter(
                    x=df["timestamp"], y=df["vol_avg"],
                    line=dict(color="#FFD740", width=1, dash="dash"),
                    name="Vol Avg",
                ), row=2, col=1)

            fig.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor=bg_color,
                height=620,
                margin=dict(l=10, r=10, t=30, b=10),
                xaxis_rangeslider_visible=False,
                legend=dict(orientation="h", yanchor="bottom", y=1.02),
                font=dict(family="monospace"),
            )
            fig.update_yaxes(title_text="Price (USDT)", row=1, col=1)
            fig.update_yaxes(title_text="Volume",       row=2, col=1)

            st.plotly_chart(fig, use_container_width=True)

            # ── Trend strength gauge ──────────────────────────────────────
            st.subheader("📡 Trend Strength Meter")
            ts_clamped = max(-0.05, min(0.05, sig_info["trend_strength"]))
            gauge_fig  = go.Figure(go.Indicator(
                mode="gauge+number+delta",
                value=ts_clamped * 100,
                delta={"reference": 0, "valueformat": ".3f"},
                gauge={
                    "axis": {"range": [-5, 5]},
                    "bar":  {"color": trend_info["trend_color"]},
                    "steps": [
                        {"range": [-5, -2], "color": "#d50000"},
                        {"range": [-2, -0.5], "color": "#ff6d00"},
                        {"range": [-0.5, 0.5], "color": "#ffd740"},
                        {"range": [0.5, 2], "color": "#69f0ae"},
                        {"range": [2, 5], "color": "#00c853"},
                    ],
                    "threshold": {"value": ts_clamped * 100, "line": {"color": "white", "width": 3}},
                },
                title={"text": "Trend Strength (%)"},
                number={"suffix": "%", "valueformat": ".3f"},
            ))
            gauge_fig.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                height=250,
                margin=dict(l=20, r=20, t=40, b=20),
            )
            st.plotly_chart(gauge_fig, use_container_width=True)

            # ── Signal history ────────────────────────────────────────────
            st.subheader("📜 Recent Signals")
            sig_df = load_signals(symbol, timeframe, 20)
            if not sig_df.empty:
                def color_signal(val):
                    if val == "BUY":  return "color: #00c853; font-weight:bold"
                    if val == "SELL": return "color: #d50000; font-weight:bold"
                    return "color: #ffd740"
                st.dataframe(
                    sig_df[["created_at", "signal", "price", "ema7", "ema14",
                             "ema21", "trend_strength", "volume_ratio"]]
                    .style.applymap(color_signal, subset=["signal"]),
                    use_container_width=True, height=240,
                )
            else:
                st.info("No signals recorded yet.")

            st.caption(f"Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')} — "
                       f"Auto-refresh every {refresh}s")

    render_live()
    time.sleep(refresh)
    st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 2 — BACKTEST
# ═══════════════════════════════════════════════════════════════════════════════
with tab_backtest:
    st.header("🔬 Strategy Backtest")
    col1, col2 = st.columns([2, 1])
    with col1:
        bt_symbol    = st.selectbox("Symbol",    ["BTC/USDT", "ETH/USDT", "BNB/USDT"], key="bt_sym")
        bt_timeframe = st.selectbox("Timeframe", config.TIMEFRAMES, index=2, key="bt_tf")
        bt_candles   = st.slider("Historical candles", 100, 1000, 500, 50)
    with col2:
        bt_balance   = st.number_input("Initial balance ($)", 100.0, 1_000_000.0, config.INITIAL_BALANCE)
        bt_sl        = st.slider("Stop Loss %",  0.5, 10.0, config.STOP_LOSS_PCT  * 100, 0.5) / 100
        bt_tp        = st.slider("Take Profit %",0.5, 20.0, config.TAKE_PROFIT_PCT* 100, 0.5) / 100
        bt_pos       = st.slider("Position %",   1.0, 50.0, config.POSITION_SIZE_PCT*100,1.0) / 100

    if st.button("▶️ Run Backtest", type="primary"):
        with st.spinner("Running backtest on historical data…"):
            try:
                bt_df  = fetch_ohlcv(bt_symbol, bt_timeframe, bt_candles)
                result = run_backtest(bt_df, bt_balance, bt_sl, bt_tp, bt_pos)
            except Exception as e:
                st.error(f"Backtest error: {e}")
                st.stop()

        # Metrics
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Trades",   result["total_trades"])
        m2.metric("Win Rate",       f"{result['win_rate']:.1f}%")
        m3.metric("Total Return",   f"{result['total_return']:+.2f}%",
                  delta=f"${result['total_pnl']:+.2f}")
        m4.metric("Sharpe Ratio",   result["sharpe_ratio"])

        m5, m6, m7, m8 = st.columns(4)
        m5.metric("Profit Factor",  result["profit_factor"])
        m6.metric("Max Drawdown",   f"{result['max_drawdown']:.2f}%")
        m7.metric("Wins",           result["winning"])
        m8.metric("Losses",         result["losing"])

        # Equity curve
        st.subheader("📈 Equity Curve")
        eq_fig = go.Figure()
        eq_fig.add_trace(go.Scatter(
            y=result["equity_curve"],
            mode="lines",
            line=dict(color="#00c853", width=2),
            fill="tozeroy",
            fillcolor="rgba(0,200,83,0.1)",
            name="Portfolio Value",
        ))
        eq_fig.add_hline(y=bt_balance, line_dash="dash", line_color="#ffd740",
                         annotation_text="Initial balance")
        eq_fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            height=350,
            margin=dict(l=10, r=10, t=20, b=10),
        )
        st.plotly_chart(eq_fig, use_container_width=True)

        # Trade list
        if not result["trade_df"].empty:
            st.subheader("📋 Trade Log")
            disp_cols = [c for c in ["side","entry","exit","pnl","pnl_pct","status"]
                         if c in result["trade_df"].columns]
            st.dataframe(result["trade_df"][disp_cols], use_container_width=True, height=300)


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 3 — PAPER TRADING
# ═══════════════════════════════════════════════════════════════════════════════
with tab_paper:
    st.header("💼 Paper Trading Portfolio")
    trader = st.session_state.paper_trader
    port   = trader.portfolio()

    p1, p2, p3, p4 = st.columns(4)
    p1.metric("💰 Balance",     f"${port['balance']:,.2f}")
    p2.metric("📊 Total P&L",   f"${port['total_pnl']:+.2f}")
    p3.metric("🏆 Win Rate",    f"{port['win_rate']:.1f}%")
    p4.metric("📈 Trades",      f"{port['total_trades']} ({port['wins']}W/{port['losses']}L)")

    st.divider()

    if port["open_trade"]:
        st.info(f"🟡 **Open Position** — {port['open_side']} @ ${port['open_price']:,.2f}")
    else:
        st.success("✅ No open position")

    # Risk summary
    rm = trader.rm
    st.subheader("🛡️ Risk Settings")
    r1, r2, r3 = st.columns(3)
    r1.metric("Stop Loss",    f"{config.STOP_LOSS_PCT*100:.1f}%")
    r2.metric("Take Profit",  f"{config.TAKE_PROFIT_PCT*100:.1f}%")
    r3.metric("Risk/Reward",  f"1:{rm.risk_reward_ratio():.1f}")

    st.divider()
    st.subheader("📋 Trade History")
    trades_df = load_trades(symbol)
    if not trades_df.empty:
        def color_pnl(val):
            try:
                return "color: #00c853" if float(val) > 0 else "color: #d50000"
            except Exception:
                return ""
        disp = trades_df[["side","entry_price","exit_price","pnl","pnl_pct","status","entry_time","exit_time"]]
        st.dataframe(disp.style.applymap(color_pnl, subset=["pnl","pnl_pct"]),
                     use_container_width=True, height=350)

        # P&L chart
        closed = trades_df[trades_df["status"] != "OPEN"].copy()
        if not closed.empty:
            closed["cum_pnl"] = closed["pnl"].cumsum()
            pnl_fig = go.Figure()
            pnl_fig.add_trace(go.Bar(
                x=list(range(len(closed))),
                y=closed["pnl"],
                marker_color=["#00c853" if v > 0 else "#d50000" for v in closed["pnl"]],
                name="Trade P&L",
            ))
            pnl_fig.add_trace(go.Scatter(
                x=list(range(len(closed))),
                y=closed["cum_pnl"],
                line=dict(color="#FFD740", width=2),
                name="Cumulative P&L",
                yaxis="y2",
            ))
            pnl_fig.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                height=300,
                yaxis2=dict(overlaying="y", side="right"),
                margin=dict(l=10, r=10, t=20, b=10),
            )
            st.plotly_chart(pnl_fig, use_container_width=True)
    else:
        st.info("No trades yet — signals will trigger paper trades automatically.")


# ═══════════════════════════════════════════════════════════════════════════════
# TAB 4 — LOGS & DB
# ═══════════════════════════════════════════════════════════════════════════════
with tab_logs:
    st.header("📋 Database Logs")
    l1, l2 = st.columns(2)

    with l1:
        st.subheader("📡 Signal Log")
        sig_all = load_signals(symbol, timeframe, 100)
        if not sig_all.empty:
            st.dataframe(sig_all, use_container_width=True, height=400)
        else:
            st.info("No signals yet.")

    with l2:
        st.subheader("💼 Trade Log")
        trades_all = load_trades()
        if not trades_all.empty:
            st.dataframe(trades_all, use_container_width=True, height=400)
        else:
            st.info("No trades yet.")

    st.divider()
    st.subheader("🤖 Future AI Module Slot")
    st.info("""
    **Modular AI Upgrade Points (ready for integration):**
    - 🧠 LSTM price prediction → replace `signal_engine.classify_signal()`
    - 🌲 XGBoost confidence scorer → add `ai_confidence` column to signals table
    - 🔮 Transformer model → plug into `indicators.add_all_indicators()`
    - 📊 AI confidence threshold: currently set to {:.0f}%
    """.format(config.AI_CONFIDENCE_THRESHOLD * 100))
