"""
Anti-Gravity EMA Trading System
Data Fetcher — Binance free API via ccxt
"""
import ccxt
import pandas as pd
import numpy as np
import time
from typing import Optional
from config import config


def _exchange() -> ccxt.binance:
    """Return a Binance exchange instance (public endpoint, no keys needed for OHLCV)."""
    return ccxt.binance({
        "apiKey": config.BINANCE_API_KEY or None,
        "secret": config.BINANCE_SECRET or None,
        "enableRateLimit": True,
        "options": {"defaultType": "spot"},
    })


def fetch_ohlcv(
    symbol: str = config.SYMBOL,
    timeframe: str = config.TIMEFRAME,
    limit: int = config.CANDLE_LIMIT,
    retries: int = 3,
) -> pd.DataFrame:
    """
    Fetch OHLCV candlestick data from Binance.
    Returns a DataFrame with columns:
        timestamp, open, high, low, close, volume
    """
    ex = _exchange()
    for attempt in range(retries):
        try:
            raw = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            df = pd.DataFrame(
                raw, columns=["timestamp", "open", "high", "low", "close", "volume"]
            )
            df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
            df = df.astype({
                "open": float, "high": float, "low": float,
                "close": float, "volume": float,
            })
            df.sort_values("timestamp", inplace=True)
            df.reset_index(drop=True, inplace=True)
            return df
        except (ccxt.NetworkError, ccxt.RequestTimeout) as e:
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
            else:
                raise RuntimeError(f"Failed to fetch OHLCV after {retries} attempts: {e}")
        except ccxt.ExchangeError as e:
            raise RuntimeError(f"Exchange error: {e}")


def fetch_ticker(symbol: str = config.SYMBOL) -> dict:
    """Return the latest ticker for a symbol."""
    ex = _exchange()
    return ex.fetch_ticker(symbol)


def fetch_order_book(symbol: str = config.SYMBOL, limit: int = 10) -> dict:
    """Fetch order book depth."""
    ex = _exchange()
    return ex.fetch_order_book(symbol, limit=limit)


def get_available_symbols() -> list:
    """Return all USDT trading pairs from Binance."""
    ex = _exchange()
    ex.load_markets()
    return sorted([s for s in ex.symbols if s.endswith("/USDT")])
